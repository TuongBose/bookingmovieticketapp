package com.project.bookingmovieticketapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingmovieticketappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingmovieticketappApplication.class, args);
	}

}
