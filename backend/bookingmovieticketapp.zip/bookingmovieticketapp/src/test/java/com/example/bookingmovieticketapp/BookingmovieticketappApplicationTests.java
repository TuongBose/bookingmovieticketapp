package com.example.bookingmovieticketapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingmovieticketappApplicationTests {

	@Test
	void contextLoads() {
	}

}
